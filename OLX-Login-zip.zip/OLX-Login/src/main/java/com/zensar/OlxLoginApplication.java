package com.zensar;

import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.slf4j.Logger;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class OlxLoginApplication {
	private static final Logger log = LoggerFactory.getLogger(OlxLoginApplication.class);
	public static void main(String[] args) {
//		log.info("hiiii this is manthan");
		SpringApplication.run(OlxLoginApplication.class, args);
	}
}
