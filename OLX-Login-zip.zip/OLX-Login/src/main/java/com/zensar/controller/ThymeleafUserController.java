package com.zensar.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.zensar.model.Users;
import com.zensar.service.OlxUserService;



@Controller
public class ThymeleafUserController
{
	@Autowired
	OlxUserService userService;

	private static final Logger log = LoggerFactory.getLogger(ThymeleafUserController.class);

	@RequestMapping("/testMvc")
	public String getMvcpage(ModelMap modelMap)
	{
		log.debug("getMvcpage fro testMvc called up");
		//Model
		modelMap.put("name","manthan nazarkar");

		return "test-mvc"; //assumig name of page html is added automatically by thymeleaf
	}

	@RequestMapping("/allUsers")
	public String getAllUsers(ModelMap modelMap)
	{
		log.debug("getAllUsers called up");
		//Model
		List<Users> userList = userService.findAll();
		System.out.println(userList);
		modelMap.put("name","Dinesh Kumar");
		modelMap.put("allusers",userList);

		return "test-mvc"; //assumig name of page html is added automatically by thymeleaf
	}

	@GetMapping("/mymessage")
	public String showMessage(@RequestParam("username") String name,ModelMap model) {
		List<String> messages = Arrays.asList("you are registered","meeting at 5 p.m.");
		model.put("name", name);
		model.put("time", new Date());
		model.put("messages", messages);
		return "show-message";
	}

}