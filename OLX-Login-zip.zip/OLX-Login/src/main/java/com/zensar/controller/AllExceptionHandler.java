package com.zensar.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class AllExceptionHandler extends ResponseEntityExceptionHandler {
	
	private static final Logger log = LoggerFactory.getLogger(AllExceptionHandler.class);
	
	@ExceptionHandler(UserNotFoundException.class)
	public String handleUserNotFound() {
		log.error("User Not Found");
		return "This user does not exists!!!";
	}
	
	@ExceptionHandler(Exception.class)
	public String handleSomeException(Exception ex) {
		log.error("{}",ex);
		return "Some Error Occured!!!";
	}
}
