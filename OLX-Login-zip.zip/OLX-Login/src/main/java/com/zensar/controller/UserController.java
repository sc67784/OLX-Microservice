package com.zensar.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.OlxLoginApplication;
import com.zensar.model.Users;
import com.zensar.service.AuthTokenService;
import com.zensar.service.AuthTokenServiceImplJWT;
import com.zensar.service.JwtUtilService;
import com.zensar.service.OlxUserDetail;
import com.zensar.service.OlxUserDetailFull;
import com.zensar.service.OlxUserService;

@RestController
public class UserController {
	@Autowired
	OlxUserService ous;
	
	@Autowired
	AuthTokenService ats;
	
	@Autowired
	AuthTokenServiceImplJWT ats1;
	
	@Autowired
	JwtUtilService jus;
	
	
	private static final Logger log = LoggerFactory.getLogger(UserController.class);
	
	@PostMapping(path="/user/authenticate",consumes="application/json")
	public String loginUser(@RequestBody OlxUserDetail userDetail) {
		String authToken = ats1.generateToken(userDetail);
		System.out.println(authToken);
		return authToken;
	}
	
	@DeleteMapping(path="/user/logout")
	public boolean logoutUser(@RequestHeader("Authorization") String token) {
		String username = jus.getUserName(token);
		if(jus.validateToken(token, username)) {
		boolean t =ats1.logOutUser(token);
		return t;
		}else {
			return false;
		}
		
	}

	@PostMapping(path="/user",consumes="application/json")
	public Users regUser(@RequestBody OlxUserDetailFull ud) {
		Users u1 = ous.registerUser(ud);
		return u1;
	}
	
	@GetMapping(path="/user")
	public Users getUserInfo(@RequestHeader("Authorization") String token ) throws UserNotFoundException {
		String username=jus.getUserName(token);
		if(jus.validateToken(token, username)) {
		Users u1 = ous.getUser(username);
		return u1;
		}else {
			throw new UserNotFoundException("User Not Found");
//			return null;
		}
		
	}
	
	@GetMapping(path="/token/validate")
	public boolean validateToken(@RequestHeader("Authorization") String token) {
		String username = jus.getUserName(token);
		boolean t = jus.validateToken(token, username);
		
		return t;
	}
	
//	@GetMapping(path="/user/getname/{name}")
//	public String getName(@PathVariable("name") String name) {
//		String n1 = ous.getName(name);
////		System.out.println("hiii"+n1);
//		return n1;
//		
//	}
	
}
