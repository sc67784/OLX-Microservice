package com.zensar.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.zensar.controller.UserController;
import com.zensar.model.Users;
import com.zensar.repository.UsersRepo;
@Service
public class AuthTokenServiceImpl implements AuthTokenService{
	
	@Autowired
	UsersRepo ur;
	
	private static final Logger log = LoggerFactory.getLogger(AuthTokenServiceImpl.class);
	
	@Override
	public boolean authToken(String authToken) {
		String token = authToken.substring("Auth-Token-".length());
		Users u1 = ur.findByUserName(token).get(0);
		
		if(u1!=null && token.equals(u1.getUserName())) {
			log.info("Token Validated Succesfully!!!");
			return true;
		}else {
			log.warn("Token is Wrong!!!");
			return false;
		}
	}

	@Override
	public String generateToken(OlxUserDetail userDetail) {
		// TODO Auto-generated method stub
		return "hiii";
	}

	@Override
	public String getUserName(String authToken) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean ValidateToken(String token) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean logOutUser(String token) {
		// TODO Auto-generated method stub
		return false;
	}

}
