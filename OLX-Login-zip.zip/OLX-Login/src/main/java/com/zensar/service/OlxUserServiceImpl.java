package com.zensar.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zensar.OlxLoginApplication;
import com.zensar.model.Users;
import com.zensar.repository.UsersRepo;
@Service
public class OlxUserServiceImpl implements OlxUserService {
	@Autowired
	UsersRepo ur;
	@Autowired
	AuthTokenService ats;

	private static final Logger log = LoggerFactory.getLogger(OlxUserServiceImpl.class);
	
	@Override
	public String userLogin(OlxUserDetail userDetail) {
		Users u1 = ur.findByUserName(userDetail.getUserName()).get(0);
		if(u1!=null) {
			log.info("returning auth-token for "+userDetail);
			return "Auth-Token-"+userDetail.getUserName();
//			return ats.generateToken(userDetail);
			
		}else {
			return "wrong!!!!";
		}
	}


	@Override
	public boolean logoutUser1(String token) {
		
		String token1 = token.substring("Auth-Token-".length());
//		System.out.println(token1);
		boolean u1 = ur.existsByUserName(token1);
		return u1;
		
	}


	@Override
	@Transactional
	public Users registerUser(OlxUserDetailFull ud) {
		Users u1 = new Users(0,ud.getUserName(),ud.getPassword(),
				"user",true,ud.getFirstname(),ud.getLastname(),ud.getEmail(),ud.getPhone());
		ur.save(u1);
		return u1;
	}


	@Override
	public Users getUser(String username) {
		
//		String token1 = token.substring("Auth-Token-".length());
		List<Users> u1 = ur.findByUserName(username);
		return u1.get(0);
		
	}


	@Override
	public String getName(String token) {
		Users u1 = ur.findByUserName(token).get(0);
		String n1 = u1.getFirstName()+" "+u1.getLastName();
		return n1;
	}


	@Override
	public List<Users> findAll() {
		List<Users> list = ur.findAll();
		System.out.println("hiii");
		return list;
	}
	
}
