package com.zensar.service;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zensar.model.Jwtoken;
//import com.zensar.controller.UserController;
import com.zensar.model.Users;
import com.zensar.repository.JwtokenRepo;
import com.zensar.repository.UsersRepo;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
@Service
@Primary
public class AuthTokenServiceImplJWT implements AuthTokenService{
	@Autowired
	JwtUtilService jwtUtilService;
	
	@Autowired
	UsersRepo ur;
	
	@Autowired
	JwtokenRepo jr;
	
	private static final Logger log = LoggerFactory.getLogger(AuthTokenServiceImplJWT.class);
	
	@Override
	public boolean authToken(String authToken) {
		return false;
//		String token = authToken.substring("Auth-Token-".length());
//		Users u1 = ur.findByUserName(token).get(0);
//		
//		if(u1!=null && token.equals(u1.getUserName())) {
//			log.info("Token Validated Succesfully!!!");
//			return true;
//		}else {
//			log.warn("Token is Wrong!!!");
//			return false;
//		}
	}

	@Override
	@Transactional
	public String generateToken(OlxUserDetail userDetail) {
		log.debug("generating token for "+userDetail.getUserName());
		String username = userDetail.getUserName();
		String password = userDetail.getPassword();
		List<Users> list = ur.findByUserName(username);
		System.out.println(list.size());
		if(list.size()==0)
			return "User Not Found";
		boolean pwdMatch = list.get(0).getPassword().equals(password);
		String token="";
		if(pwdMatch==true) {
			int d = list.get(0).getId();
//			System.out.println("hiii");
			token = jwtUtilService.generateToken(new HashMap<>(), username);
			log.debug("got username and password matched "+pwdMatch);
			jr.save(new Jwtoken(d,token));
			return token;
		}else {
		return "Password is Wrong";
		}
	}

	@Override
	public String getUserName(String authToken) {
		String username = jwtUtilService.getUserName(authToken);
		return username;
	}

	@Override
	public boolean ValidateToken(String token) {
		try {
			Claims jwt = Jwts.parser().setSigningKey("mysecret").parseClaimsJws(token).getBody();
			System.out.println(jwt);
			return true;
		}catch(Exception e) {
			return false;
		}
		
	}

	@Override
	@Transactional
	public boolean logOutUser(String token) {
		Jwtoken j = jr.findByJwt(token);
		System.out.println(j);
		if(j!=null) {
		jr.delete(j);
		return true;
		}else {
			return false;
		}
	}

}
