package com.zensar.service;

public class OlxUserDetailFull {
	String firstname;
	String lastname;
	String userName;
	String password;
	String email;
	String phone;
	
	public OlxUserDetailFull(String firstname, String lastname, String userName, String password, String email,
			String phone) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.phone = phone;
	}

	public OlxUserDetailFull(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
	public OlxUserDetailFull() {
		super();
	}

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
