package com.zensar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.zensar.controller.UserNotFoundException;
import com.zensar.model.UserDetailsWrapper;
import com.zensar.model.Users;
import com.zensar.repository.UsersRepo;

@Service
@Primary
public class UserDetailsServiceImplJpa implements UserDetailsService
{
	
	/*
	 * class in db : Users username, password, roles
	 */
	@Autowired
	private UsersRepo userRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
	 {List<Users> list = userRepo.findByUserName(username);
		try{
			
			if(list.size() == 0)
				throw new UserNotFoundException("User not found Username : " + username);
		}catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Users user = list.get(0);
		return new UserDetailsWrapper(user);
//		return null;
	} 

}