package com.zensar.service;

public interface AuthTokenService {
	boolean authToken(String authToken);
	public String generateToken(OlxUserDetail userDetail);
	public String getUserName(String authToken);
	public boolean ValidateToken(String token);
	public boolean logOutUser(String token);
}
