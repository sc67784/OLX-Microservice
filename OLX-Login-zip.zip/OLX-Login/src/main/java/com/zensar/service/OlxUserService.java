package com.zensar.service;

import java.util.List;

import com.zensar.model.Users;

public interface OlxUserService {
	String userLogin(OlxUserDetail userDetail);
	boolean logoutUser1(String token);
	Users registerUser(OlxUserDetailFull ud);
	Users getUser(String token);
	String getName(String token);
	List<Users> findAll();
}
