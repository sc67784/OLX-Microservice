package com.zensar.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Jwtoken {
	@Id
	int id;
	String jwt;
	
	public Jwtoken() {
		super();
	}
	public Jwtoken(int id, String jwt) {
		super();
		this.id = id;
		this.jwt = jwt;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getJwt() {
		return jwt;
	}
	public void setJwt(String jwt) {
		this.jwt = jwt;
	}
	
}
