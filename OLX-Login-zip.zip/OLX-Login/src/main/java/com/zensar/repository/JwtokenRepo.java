package com.zensar.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zensar.model.Jwtoken;

public interface JwtokenRepo extends JpaRepository<Jwtoken, Integer>{
	public Jwtoken findByJwt(String token);
}
