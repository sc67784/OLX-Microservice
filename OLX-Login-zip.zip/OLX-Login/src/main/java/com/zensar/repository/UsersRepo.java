package com.zensar.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zensar.model.Users;

public interface UsersRepo extends JpaRepository<Users, Integer>
{
	public List<Users> findByUserName(String username);
	public boolean existsByUserName(String username);
}
