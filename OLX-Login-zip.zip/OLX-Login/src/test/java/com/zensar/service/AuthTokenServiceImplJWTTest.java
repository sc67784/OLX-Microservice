package com.zensar.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthTokenServiceImplJWTTest {
	@Autowired
	AuthTokenServiceImplJWT atj;

	@Test
	void testGenerateToken() {
		OlxUserDetail od = new OlxUserDetail();
		od.setUserName("meera1");
		od.setPassword("meera123");
		String token = atj.generateToken(od);
		assertNotNull(token);
	}

	@Test
	void testGetUserName() {
		OlxUserDetail od2 = new OlxUserDetail();
		od2.setUserName("manthan1");
		od2.setPassword("manthan123");
		String token = atj.generateToken(od2);
		String u = atj.getUserName(token);
//		System.out.println(u+"jiii");
		assertEquals(u, od2.getUserName());
	}
	@Test
	void testValidateToken() {
		OlxUserDetail od1 = new OlxUserDetail();
		od1.setUserName("sameer1");
		od1.setPassword("sameer123");
		String token = atj.generateToken(od1);
		boolean t = atj.ValidateToken(token);
		assertEquals(t, true);
	}

}
