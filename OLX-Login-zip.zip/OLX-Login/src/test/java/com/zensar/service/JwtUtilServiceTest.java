package com.zensar.service;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class JwtUtilServiceTest {
	@Autowired
	JwtUtilService jwtUtilService;
	
	@Test
	void testGenerateToken() {
		Map<String,Object> map = new HashMap<>();
		map.put("trainee", "Manthan");
		map.put("trainer", "Dinesh");
		map.put("Course", "Java Full Stack");
		
		String token = jwtUtilService.generateToken(map, "manthan1");
		System.out.println(token);
		
	}

	@Test
	void testGetClaims() {
	}

	@Test
	void testValidateToken() {
	}

	@Test
	void testGetUserName() {
	}

	@Test
	void testGetExpiration() {
	}

}
